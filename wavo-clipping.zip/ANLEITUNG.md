# Wavo Clipping Skill für Claude Code – Installation

Damit macht Claude Code aus einem langen Video automatisch fertige Clips für TikTok, Reels und Shorts.

**Du brauchst:** einen Computer (Windows oder Mac), ein Claude-Abo (Pro oder Max) und Claude Code.

## 1. Claude Code installieren
Folge der offiziellen Anleitung auf claude.com (Claude Code) und melde dich mit deinem Claude-Account an.

## 2. Skill installieren
1. Die ZIP-Datei `wavo-clipping.zip` herunterladen und entpacken. Darin ist ein Ordner `wavo-clipping`.
2. Diesen Ordner hierhin verschieben:
   - **Windows:** `C:\Users\<DEIN NAME>\.claude\skills\wavo-clipping`
   - **Mac:** `~/.claude/skills/wavo-clipping`
   Gibt es den Ordner `skills` noch nicht, leg ihn an. (`.claude` ist ein versteckter Ordner: Windows → Explorer → Ansicht → Ausgeblendete Elemente; Mac → im Finder `Cmd + Shift + .`)
3. Am Ende muss es so aussehen: `.claude/skills/wavo-clipping/SKILL.md`

## 3. Loslegen
1. Einen Ordner anlegen, z. B. `Clipping` auf dem Desktop.
2. Claude Code in diesem Ordner starten.
3. Diesen Prompt schicken (Link und Briefing anpassen):

```
Nutze den Skill wavo-clipping.
Video: <LINK ZUM VIDEO>
Briefing der Kampagne:
- Pflicht-Caption/Hashtags: <aus dem Briefing kopieren>
- Länge: <z. B. 20–60 Sekunden>
- Sonstiges: <z. B. Logo oben rechts, nur englische Überschriften>
```

Beim ersten Mal prüft Claude, ob alles installiert ist (ffmpeg, yt-dlp, Spracherkennung), und installiert fehlende Teile nach deinem Okay. Danach bekommst du eine Tabelle mit den besten Stellen. Erst wenn du zustimmst, werden die Clips geschnitten.

## Wichtig
- Nur Material aus Kampagnen clippen, bei denen du mitmachst.
- Pflicht-Angaben aus dem Briefing immer mitgeben, sonst kennt Claude sie nicht.
- Fragen? → #support im Wavo-Discord.
